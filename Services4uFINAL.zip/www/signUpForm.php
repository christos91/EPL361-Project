<?php session_start();  ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/index.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>

<!-- InstanceBeginEditable name="doctitle" -->
<title>Services4u</title>
<!-- InstanceEndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/droid_sans_400-droid_sans_700.font.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
<style type="text/css">
.hide{
border:0px;

}
.Asize{

text-align:left;
font-size:20px;}
.round{
border-radius:10px;
border-collapse:collapse;
}
#apDiv1 {
	position:absolute;
	width:200px;
	height:115px;
	z-index:1;
}
</style>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<style type="text/css">
#apDiv2 {
	position:absolute;
	width:200px;
	height:37px;
	z-index:1;
	left: 761px;
	top: 129px;
}
</style>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <ul id="MenuBar1" class="MenuBarHorizontal">
<li><a href="#" class="MenuBarItemSubmenu" id="usernames"></a>
  <ul>
    <li><a href="changeProfile.php">Change Info</a></li>
    <li><a href="AddJobForm.php">Add Job</a></li>
    <li><a href="#">Message</a></li>
    <li><a href="logOutCode.php">Log Out</a></li>
  </ul>
</li>
          </ul>
        </form>
 
        
      </div>
      <div class="logo">
        <h1 align="left"><a href="index.php"><span>Services4u</span></a></h1>
      </div>
      <div class="clr"></div>
      <div class="menu_nav">
        <ul>
          <li ><a href="index.php"><span>Home Page</span></a></li>
          <li><a href="SearchForPro.php"><span>Pros</span></a></li>
          <li><a href="SearchJobForm.php"><span>Jobs</span></a></li>
          <li><a id="signUp" href="signUpForm.php"><span>Sign Up</span></a></li>
          <li><a id="LogIn"href="logInForm.php"><span>Log In</span></a></li>
        

        </ul>
      </div>
      <div class="clr"></div>
      <div class="slider">
       <div id="coin-slider"> <a href="#"><img src="images/slide1.jpg" width="960" height="360" alt="" />
            </a> <a href="#"><img src="images/slide2.jpg" width="960" height="360" alt="" />
          </a> <a href="#"><img src="images/slide3.jpg" width="960" height="360" alt="" />
          </a> </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize"><!-- InstanceBeginEditable name="EditRegion3" -->
      <div class="mainbar">
        <div class="article">
          <h2><span>Sign Up </span></h2>
          <p class="infopost">
          <form id="form1" action="signUpCode.php" method="post">
<table width="200"  class="hide">
  <tr>
    <th class= "Asize" scope="row">&nbsp;Name</th>
    <td>&nbsp;<input align="left"; class="round"id="name" name="name"  autofocus="autofocus"type="text" value="<?php  if(isset( $_SESSION['name']))echo $_SESSION['name'];?>" required></td>
  </tr>
  <tr>
    <th class= "Asize" scope="row">&nbsp;Username</th>
    <td>&nbsp;<input class="round" id="user" name="user"type="text"value="<?php  if(isset( $_SESSION['user']))echo $_SESSION['user'];?>" required></td>
  </tr>
  <tr>
    <th class= "Asize" scope="row">&nbsp;Password</th>
    <td>&nbsp;<input class="round" name="pass" type="password"required></p></td>
  </tr>
  <tr>
    <th  class= "Asize" scope="row">&nbsp;Email</th>
    <td>&nbsp;<input class="round" name="email" type="email"value="<?php  if(isset( $_SESSION['email']))echo $_SESSION['email'];?>" required></td>
  </tr>
  <tr>
    <th class= "Asize" scope="row">&nbsp;Town</th>
    <td>&nbsp;<select class="round" name="town" size="1" id="town" title="town" required >
<option value="" selected="selected"> </option>  
  <option>Famagusta</option>
  <option>Nicosia</option>
  <option>Limassol</option>
  <option>Larnaka</option>
  <option>Pafos</option>
</select></td> 
  </tr>
  <tr>
    <th class= "Asize" scope="row">&nbsp;Description</th>
    <td>&nbsp;<textarea  class="round" name="description" cols="30" rows="5" ><?php  if(isset( $_SESSION['description']))echo $_SESSION['description'];?><?php  if(!isset( $_SESSION['description']))echo "Enter your description here...";?> </textarea > 
	 </td>
  </tr>
   <tr>
    <th  class= "Asize" scope="row">&nbsp;Telephone</th>
    <td>&nbsp;<input class="round" id="telephone" name="telephone"type="number" value="<?php  if(isset( $_SESSION['telephone']))echo $_SESSION['telephone'];?>" required></td>
  </tr>
</table>
 <?php
if(isset($_SESSION['singup'])){
if(($_SESSION['singup'])==0){
echo "<script>alert(\"Username already exists!\");</script>";
 session_destroy(); }

}
?>

 <p><input class="round" type="submit" value="Sing Up"></p>
 </form>&nbsp;</p>
          <div class="clr"></div>
          <div class="img"></div>
          <div class="clr"></div>
        </div>
      </div>
    <!-- InstanceEndEditable -->
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Contact </span> Us</h2>
          <div class="clr"></div>
        <p class="contact_info"> <span>Address:</span> 2025 Kallipoleos 20,<br />
          <span>&nbsp;</span> Nicosia<br />
          <span>Telephone:</span> +357 22 895657<br />
          <span>E-mail: info@services4u.com</span></p>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="col c1" style="color:#000">
        <h2 style="color:#000"><span>Need a </span> Job?</h2>
        <p>Browse between different types of posted jobs. 
        Find one that suits your specialty and apply for it. <br> <br> 
        Get hired! Get payed!</p> </div>
      <div class="col c2" style="color:#000">
        <h2 style="color:#000"><span>Need a </span> Pro?</h2>
        
        <p>Post your own ads requesting for a job. 
        Pick the PRO that you consider the best for the job.<br> <br>
        Its as simple as that!</p>
      </div>
      <div class="col c3" style="color:#000">
        <h2 style="color:#000"><span>Be a part of</span> this!</h2>
        <p>Sign up and be a part of this community to provide and ask for help from other members. 
        Make your life easier, as so many others have already done.</p>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">www.services4u.com</a>.</p>
      <p class="rf"> <a href="http://www.dreamtemplate.com/"></a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
<script type="text/javascript">
function rename(){
var varname = '<?php echo $_SESSION['username']; ?>';
  alert("Welcome " + varname);
var text=document.getElementById("usernames");
  text.innerHTML="Username:"+varname;}
  function rename2(){
var varname = '<?php echo $_SESSION['username']; ?>';
 
var text=document.getElementById("usernames");
  text.innerHTML="Username:"+varname;}
</script>"
<?php 
if(isset($_SESSION["error_connect_to_mysql"])){
	
	echo "
<script type=\"text/javascript\">

alert(\"Sorry Error with our servers Sory for the inconvenience\");

</script>";
	
	session_destroy();
	}


 ?>
<?php

if(isset($_SESSION['id'])){

	
echo "
<script type=\"text/javascript\">


document.getElementById(\"MenuBar1\").style.display=\"block\";
document.getElementById(\"LogIn\").href=\"../logOutCode.php\";
document.getElementById(\"LogIn\").innerHTML=\"Log Out\";
</script>";
echo "<script type=\"text/javascript\">rename2();
document.getElementById(\"signUp\").href=\"#\";
</script>";
if($_SESSION['is_in']==0){

 echo "<script type=\"text/javascript\">rename();
</script>";  
$_SESSION['is_in']=1;
}
}else {
	echo "
<script type=\"text/javascript\">

document.getElementById(\"MenuBar1\").style.display=\"none\";
document.getElementById(\"LogIn\").style.display=\"block\";

</script>"
;
	}?>
<script type="text/javascript">
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgDown:"../SpryAssets/SpryMenuBarDownHover.gif", imgRight:"../SpryAssets/SpryMenuBarRightHover.gif"});
</script>
</body>
<!-- InstanceEnd --></html>

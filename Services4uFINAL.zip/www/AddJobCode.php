<?php
// Create connection
session_start();
$con=mysqli_connect("127.0.0.1","root","","mydabase");
// Check connection



$title=strip_tags($_POST["title"]);
$Category=strip_tags($_POST["job"]);
$payment=doubleval($_POST["payment"]);
$town=strip_tags($_POST["town"]);
$description=$_POST["description"];
echo $description; 
$date=$_POST["Expiration"];
$id=$_SESSION['id'];
if($payment<=0){
echo "malakas evales int ";
$_SESSION['payment']=0;
header("Location:AddJobForm.php");
}else echo "payment ok!!!   ";
echo $payment;

if (mysqli_connect_errno($con))
  {
  $_SESSION["error_connect_to_mysql"]=1;
  header("Location:index.php");
  }else{

$result2=mysqli_query($con,"INSERT INTO classifieds (title,payment,customerId,category,town,date,description) VALUES ('$title','$payment','$id','$Category','$town','$date','$description')");

 //
//
//echo $id;

 /*$result2=mysqli_query($con,"INSERT INTO classifieds (category,description,town,customerId,title)
VALUES ('$Category','$description','$town',35,'$title')");

*/if($result2){
header("Location:index.php");
echo "<script>alert(\"One new Job Added!!\");</script>";
}else echo "<script>alert(\"Job was not added we eror with our servers Sory for the inconvenience\");</script>";









  mysqli_close($con);
 

  }





  ?>
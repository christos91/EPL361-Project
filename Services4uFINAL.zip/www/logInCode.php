<?php
// Create connection
session_start();
$con=mysqli_connect("127.0.0.1","root","","mydabase");
// Check connection


$username=$_POST["user"];
$password=$_POST["pass"];


echo "<br/> hello, ".$password;
if (mysqli_connect_errno($con))
  {
 $_SESSION["error_connect_to_mysql"]=1;
  header("Location:index.php");
  }else{
  
$result = mysqli_query($con,"SELECT password FROM user WHERE username='$username'");

$num = mysqli_num_rows($result);
$row = mysqli_fetch_row($result);
if($num>0){
if($row[0]==$password){

$_SESSION['username']=$username;
$_SESSION['code']=0;
$id = mysqli_query($con,"SELECT id FROM user WHERE username='$username'");
$id2= mysqli_fetch_row($id);
$_SESSION['id']=$id2[0];
$_SESSION['is_in']=0;


header("Location:index.php");

}else {$_SESSION['code']=1; $_SESSION['username']=$username;header("Location:logInForm.php");}
}else {$_SESSION['code']=2; header("Location:logInForm.php");}

  }


  ?>
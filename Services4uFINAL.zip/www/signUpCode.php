<?php
// Create connection
session_start();
$con=mysqli_connect("127.0.0.1","root","","mydabase");
// Check connection



$username=strip_tags($_POST["user"]);
$password=strip_tags($_POST["pass"]);
$name=strip_tags($_POST["name"]);
$email=strip_tags($_POST["email"]);
$town=strip_tags($_POST["town"]);
$description=strip_tags($_POST["description"]);
$telephone=intval($_POST["telephone"]);
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  $_SESSION["error_connect_to_mysql"]=1;
  header("Location:index.php");
  }else{



 

 $result2=mysqli_query($con,"INSERT INTO user (email,username)
VALUES ('$email','$username')");
if($result2){
$result=mysqli_query($con,"UPDATE user SET telephone='$telephone',name='$name',password='$password',town='$town',description='$description'
WHERE username='$username'");
if($result){
$_SESSION['singup']=1;
header("Location:index.php");}
}else{$_SESSION['singup']=0;
$_SESSION["user"]=$username;
$_SESSION["name"]=$name;
$_SESSION["email"]=$email;
$_SESSION["town"]=$town;
$_SESSION["description"]=$description;
$_SESSION['telephone']=$telephone;
header("Location:signUpForm.php");

}





  mysqli_close($con);
 
  }






  ?>